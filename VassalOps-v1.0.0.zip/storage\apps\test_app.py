 import tkinter as tk\nroot=tk.Tk()\nroot.title('GM compiled App')\nroot.geometry('300x200')\ntk.Label(root, text='Hello Andy! Compiled Live!', font=('Arial', 12)).pack(pady=50)\nroot.mainloop()
